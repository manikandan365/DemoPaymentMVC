package in.co.my.bank.dao;

import java.util.List;
import java.util.logging.Logger;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import in.co.my.bank.dto.TransactionDTO;
import in.co.my.bank.util.DataUtility;




@Repository
public class TransactionDAOImpl implements TransactionDAOInt {

	private static Logger log = Logger.getLogger(TransactionDAOImpl.class.getName());
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public long add(TransactionDTO dto) {
		log.info("TransactionDAOImpl Add method Start");
		Session session = sessionFactory.getCurrentSession();
		long pk = (long) session.save(dto);
		log.info("TransactionDAOImpl Add method End");
		return pk;
	}

	@Override
	public void delete(TransactionDTO dto) {
		log.info("TransactionDAOImpl Delete method Start");
		Session session = sessionFactory.getCurrentSession();
		session.delete(dto);
		log.info("TransactionDAOImpl Delete method End");
		
	}

	@Override
	public TransactionDTO findBypk(long pk) {
		log.info("TransactionDAOImpl FindByPk method Start");
		Session session = sessionFactory.getCurrentSession();
		TransactionDTO dto = (TransactionDTO) session.get(TransactionDTO.class, pk);
		log.info("TransactionDAOImpl FindByPk method End");
		return dto;
	}

	@Override
	public TransactionDTO findByName(String name) {
		log.info("TransactionDAOImpl FindByLogin method Start");
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(TransactionDTO.class);
		criteria.add(Restrictions.eq("TransactionName", name));
		TransactionDTO dto = (TransactionDTO) criteria.uniqueResult();
		log.info("TransactionDAOImpl FindByLogin method End");
		return dto;
	}

	@Override
	public void update(TransactionDTO dto) {
		log.info("TransactionDAOImpl Update method Start");
		Session session = sessionFactory.getCurrentSession();
		session.merge(dto);
		log.info("TransactionDAOImpl update method End");
	}

	@Override
	public List<TransactionDTO> list() {
		return list(0, 0);
	}

	@Override
	public List<TransactionDTO> list(int pageNo, int pageSize) {
		log.info("TransactionDAOImpl List method Start");
		Session session = sessionFactory.getCurrentSession();
		Query<TransactionDTO> query = session.createQuery("from TransactionDTO", TransactionDTO.class);
		List<TransactionDTO> list = query.getResultList();
		log.info("TransactionDAOImpl List method End");
		return list;
	}

	@Override
	public List<TransactionDTO> search(TransactionDTO dto) {
		return search(dto, 0, 0);
	}

	@Override
	public List<TransactionDTO> search(TransactionDTO dto, int pageNo, int pageSize) {
		log.info("TransactionDAOImpl Search method Start");
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(TransactionDTO.class);
		if (dto != null) {
			if (dto.getId() > 0) {
				criteria.add(Restrictions.eq("id", dto.getId()));
			}
			if (dto.getToAccount() > 0) {
				criteria.add(Restrictions.eq("toAccount", dto.getToAccount()));
			}
			
			if (dto.getFromAccount() > 0) {
				criteria.add(Restrictions.eq("fromAccount", dto.getFromAccount()));
			}

			
			if (pageSize > 0) {
				pageNo = (pageNo - 1) * pageSize;
				criteria.setFirstResult((int) pageNo);
				criteria.setMaxResults(pageSize);
			}
		}
		log.info("TransactionDAOImpl Search method End");
		return criteria.list();
	}

	

}
