package in.co.my.bank.service;

import java.util.List;

import in.co.my.bank.dto.TransactionDTO;





public interface TransactionServiceInt {

	public long add(TransactionDTO dto);

	public void delete(TransactionDTO dto);

	public TransactionDTO findBypk(long pk);

	public TransactionDTO findByName(String name);

	public void update(TransactionDTO dto);

	public List<TransactionDTO> list();

	public List<TransactionDTO> list(int pageNo, int pageSize);

	public List<TransactionDTO> search(TransactionDTO dto);

	public List<TransactionDTO> search(TransactionDTO dto, int pageNo, int pageSize);



}
