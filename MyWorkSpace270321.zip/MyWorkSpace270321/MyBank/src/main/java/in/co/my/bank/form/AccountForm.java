package in.co.my.bank.form;

import javax.persistence.Column;

import in.co.my.bank.dto.AccountDTO;
import in.co.my.bank.dto.BaseDTO;
import in.co.my.bank.util.DataUtility;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountForm extends BaseForm {

	private String name;
	private String email;
	private String accountNo;
	private double balance;
	

	@Override
	public BaseDTO getDTO() {
		AccountDTO dto=new AccountDTO();
		dto.setName(name);
		dto.setEmail(email);
		dto.setAccountNo(DataUtility.getLong(accountNo));
		dto.setBalance(balance);
		return dto;
	}

	@Override
	public void populate(BaseDTO bDto) {
		AccountDTO dto=(AccountDTO) bDto;
		name=dto.getName();
		email=dto.getEmail();
		accountNo=String.valueOf(dto.getAccountNo());
		balance=dto.getBalance();
	}

}
