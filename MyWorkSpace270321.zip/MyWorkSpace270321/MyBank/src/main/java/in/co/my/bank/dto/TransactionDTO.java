package in.co.my.bank.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="TRANSACTION")
public class TransactionDTO extends BaseDTO {
	
	@Column(name="TRANSACTION_ID")
	private long transactionId;
	@Column(name="TO_ACCOUNT")
	private long toAccount;
	@Column(name="FROM_ACCOUNT")
	private long fromAccount;
	@Column(name="Amount")
	private double amount;
	@Column(name="DATE")
	@Temporal(TemporalType.DATE)
	private Date date;
	
	

	@Override
	public String getKey() {
		return null;
	}

	@Override
	public String getValue() {
		return null;
	}

}
