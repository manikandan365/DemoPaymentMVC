package in.co.my.bank.config;

import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.mail.javamail.JavaMailSenderImpl;

public class ExtraConfig {

	@Bean
    public JavaMailSenderImpl mailSender() {
        JavaMailSenderImpl javaMailSender = new JavaMailSenderImpl();

        Properties props = new Properties(); 
        props.put("mail.smtp.starttls.enable", "true");
        
        javaMailSender.setJavaMailProperties(props);
        javaMailSender.setHost("smtp.gmail.com");
        javaMailSender.setPort(587);
        javaMailSender.setUsername("manikandan270321@gmail.com");
        javaMailSender.setPassword("hellO123!");

        return javaMailSender;
    }
	
}
