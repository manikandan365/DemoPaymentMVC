package in.co.my.bank.dao;

import java.util.List;
import java.util.logging.Logger;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import in.co.my.bank.dto.AccountDTO;


@Repository
public class AccountDAOImpl implements AccountDAOInt {

	private static Logger log = Logger.getLogger(AccountDAOImpl.class.getName());
	
	@Autowired
	private SessionFactory sessionFactory;
	
	

	@Override
	public void delete(AccountDTO dto) {
		log.info("AccountDAOImpl Delete method Start");
		Session session = sessionFactory.getCurrentSession();
		session.delete(dto);
		log.info("AccountDAOImpl Delete method End");
		
	}

	@Override
	public AccountDTO findBypk(long pk) {
		log.info("AccountDAOImpl FindByPk method Start");
		Session session = sessionFactory.getCurrentSession();
		AccountDTO dto = (AccountDTO) session.get(AccountDTO.class, pk);
		log.info("AccountDAOImpl FindByPk method End");
		return dto;
	}

	@Override
	public AccountDTO findByLogin(String login) {
		log.info("AccountDAOImpl FindByLogin method Start");
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(AccountDTO.class);
		criteria.add(Restrictions.eq("login", login));
		AccountDTO dto = (AccountDTO) criteria.uniqueResult();
		log.info("AccountDAOImpl FindByLogin method End");
		return dto;
	}
	
	@Override
	public AccountDTO findByAccountNo(long accountNo) {
		log.info("AccountDAOImpl findByAccountNo method Start");
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(AccountDTO.class);
		criteria.add(Restrictions.eq("accountNo", accountNo));
		AccountDTO dto = (AccountDTO) criteria.uniqueResult();
		log.info("AccountDAOImpl findByAccountNo method End");
		return dto;
	}

	@Override
	public void update(AccountDTO dto) {
		log.info("AccountDAOImpl Update method Start");
		Session session = sessionFactory.getCurrentSession();
		session.merge(dto);
		log.info("AccountDAOImpl update method End");
	}

	

	@Override
	public List<AccountDTO> search(AccountDTO dto) {
		return search(dto, 0, 0);
	}

	@Override
	public List<AccountDTO> search(AccountDTO dto, int pageNo, int pageSize) {
		log.info("AccountDAOImpl Search method Start");
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(AccountDTO.class);
		if (dto != null) {
			if (dto.getId() > 0) {
				criteria.add(Restrictions.eq("id", dto.getId()));
			}
			if (dto.getAccountNo() > 0) {
				criteria.add(Restrictions.eq("accountNo", dto.getAccountNo()));
			}
			if (dto.getName() != null && dto.getName().length() > 0) {
				criteria.add(Restrictions.like("name", dto.getName() + "%"));
			}
			if (pageSize > 0) {
				pageNo = (pageNo - 1) * pageSize;
				criteria.setFirstResult((int) pageNo);
				criteria.setMaxResults(pageSize);
			}
		}
		log.info("AccountDAOImpl Search method End");
		return criteria.list();
	}

	

	

}
