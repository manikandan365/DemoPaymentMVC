package in.co.my.bank.form;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

import in.co.my.bank.dto.AccountDTO;
import in.co.my.bank.dto.BaseDTO;
import in.co.my.bank.dto.TransactionDTO;
import in.co.my.bank.util.DataUtility;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TransactionForm extends BaseForm {

	private long transactionId;
	
	@Min(value = 1,message = "To Account is required")
	@NotEmpty(message = "To Account is Required")
	private String toAccount;
	
	@Min(value = 1,message = "To Account is required")
	@NotEmpty(message = "To Account is Required")
	private String fromAccount;
	
	@NotEmpty(message = "Amount is required")
	private String amount;
	private String date;
	

	@Override
	public BaseDTO getDTO() {
		TransactionDTO dto=new TransactionDTO();
		dto.setTransactionId(transactionId);
		dto.setToAccount(DataUtility.getLong(toAccount));
		dto.setFromAccount(DataUtility.getLong(fromAccount));
		dto.setAmount(DataUtility.getDouble(amount));
		dto.setDate(DataUtility.getDate(date));
		return dto;
	}

	@Override
	public void populate(BaseDTO bDto) {
		TransactionDTO dto=(TransactionDTO) bDto;
		transactionId=dto.getTransactionId();
		toAccount=String.valueOf(dto.getToAccount());
		fromAccount=String.valueOf(dto.getFromAccount());
		amount=String.valueOf(dto.getAmount());
		date=DataUtility.getDateString(dto.getDate());
	}

}
