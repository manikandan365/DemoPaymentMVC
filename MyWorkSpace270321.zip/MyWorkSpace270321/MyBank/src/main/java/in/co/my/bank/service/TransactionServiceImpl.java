package in.co.my.bank.service;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import in.co.my.bank.dao.TransactionDAOInt;
import in.co.my.bank.dto.TransactionDTO;




@Service
public class TransactionServiceImpl implements TransactionServiceInt {

	private static Logger log=Logger.getLogger(TransactionServiceImpl.class.getName());
	
	@Autowired
	private TransactionDAOInt dao;
	
	private JavaMailSenderImpl mailSender;
	
	@Override
	@Transactional
	public long add(TransactionDTO dto)  {
		log.info("TransactionServiceImpl Add method start");
		long pk=dao.add(dto);
		log.info("TransactionServiceImpl Add method end");
		return pk;
	}

	@Override
	@Transactional
	public void delete(TransactionDTO dto) {
		log.info("TransactionServiceImpl Delete method start");
		dao.delete(dto);
		log.info("TransactionServiceImpl Delete method end");
		
	}

	@Override
	@Transactional
	public TransactionDTO findBypk(long pk) {
		log.info("TransactionServiceImpl findBypk method start");
		TransactionDTO dto=dao.findBypk(pk);
		log.info("TransactionServiceImpl findBypk method end");
		return dto;
	}

	@Override
	@Transactional
	public TransactionDTO findByName(String name) {
		log.info("TransactionServiceImpl findByTransactionName method start");
		TransactionDTO dto=dao.findByName(name);
		log.info("TransactionServiceImpl findByTransactionName method end");
		return dto;
	}

	@Override
	@Transactional
	public void update(TransactionDTO dto) {
		log.info("TransactionServiceImpl update method start");
		dao.update(dto);
		log.info("TransactionServiceImpl update method end");
	}

	@Override
	@Transactional
	public List<TransactionDTO> list() {
		log.info("TransactionServiceImpl list method start");
		List<TransactionDTO> list=dao.list();
		log.info("TransactionServiceImpl list method end");
		return list;
	}

	@Override
	@Transactional
	public List<TransactionDTO> list(int pageNo, int pageSize) {
		log.info("TransactionServiceImpl list method start");
		List<TransactionDTO> list=dao.list(pageNo, pageSize);
		log.info("TransactionServiceImpl list method end");
		return list;
	}

	@Override
	@Transactional
	public List<TransactionDTO> search(TransactionDTO dto) {
		log.info("TransactionServiceImpl search method start");
		List<TransactionDTO> list=dao.search(dto);
		log.info("TransactionServiceImpl search method end");
		return list;
	}

	@Override
	@Transactional
	public List<TransactionDTO> search(TransactionDTO dto, int pageNo, int pageSize) {
		log.info("TransactionServiceImpl search method start");
		List<TransactionDTO> list=dao.search(dto, pageNo, pageSize);
		log.info("TransactionServiceImpl search method end");
		return list;
	}
	
}
