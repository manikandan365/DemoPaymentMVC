package in.co.my.bank.util;

import java.util.HashMap;


public class EmailBuilder {
	


	public static String getForgetPasswordMessage(HashMap<String, String> map) {
		StringBuilder msg = new StringBuilder();

		msg.append("<HTML><BODY>");
		msg.append("<H1>Your password is reccovered !! " + map.get("firstName") + " " + map.get("lastName") + "</H1>");
		msg.append("<P><B>To access account user Login Id : " + map.get("login") + "<BR>" + " Password : "
				+ map.get("password") + "</B></p>");
		msg.append("</BODY></HTML>");

		return msg.toString();
	}
	
	public static String getTransactionMessage(HashMap<String, String> map) {
		StringBuilder msg = new StringBuilder();

		msg.append("<HTML><BODY>");
		msg.append("<H1>Dear, " + map.get("name")+ "</H1>");
		msg.append("Thank you for having business with us.  This is just to inform you have transferred "+map.get("amount")+" successfully to account "+map.get("account")+".");
		msg.append("<P><B>Thanks</B></p>");
		msg.append("<P>My Bank automated notification</p>");
		msg.append("</BODY></HTML>");

		return msg.toString();
	}

	

}
