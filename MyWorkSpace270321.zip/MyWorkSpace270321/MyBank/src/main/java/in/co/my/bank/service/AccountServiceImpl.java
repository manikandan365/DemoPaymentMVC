package in.co.my.bank.service;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import in.co.my.bank.dao.AccountDAOInt;
import in.co.my.bank.dto.AccountDTO;
import in.co.my.bank.util.EmailBuilder;





@Service
public class AccountServiceImpl implements AccountServiceInt {

	private static Logger log=Logger.getLogger(AccountServiceImpl.class.getName());
	
	@Autowired
	private AccountDAOInt dao;
	
	private JavaMailSenderImpl mailSender;
	
	

	@Override
	@Transactional
	public void delete(AccountDTO dto) {
		log.info("AccountServiceImpl Delete method start");
		dao.delete(dto);
		log.info("AccountServiceImpl Delete method end");
		
	}

	@Override
	@Transactional
	public AccountDTO findBypk(long pk) {
		log.info("AccountServiceImpl findBypk method start");
		AccountDTO dto=dao.findBypk(pk);
		log.info("AccountServiceImpl findBypk method end");
		return dto;
	}

	@Override
	@Transactional
	public AccountDTO findByLogin(String login) {
		log.info("AccountServiceImpl findByAccountName method start");
		AccountDTO dto=dao.findByLogin(login);
		log.info("AccountServiceImpl findByAccountName method end");
		return dto;
	}
	
	@Override
	@Transactional
	public AccountDTO findByAccountNo(long accountNo) {
		log.info("AccountServiceImpl findByAccountName method start");
		AccountDTO dto=dao.findByAccountNo(accountNo);
		log.info("AccountServiceImpl findByAccountName method end");
		return dto;
	}

	@Override
	@Transactional
	public void update(AccountDTO dto){
		log.info("AccountServiceImpl update method start");
		dao.update(dto);
		log.info("AccountServiceImpl update method end");
	}

	

	@Override
	@Transactional
	public List<AccountDTO> search(AccountDTO dto) {
		log.info("AccountServiceImpl search method start");
		List<AccountDTO> list=dao.search(dto);
		log.info("AccountServiceImpl search method end");
		return list;
	}

	@Override
	@Transactional
	public List<AccountDTO> search(AccountDTO dto, int pageNo, int pageSize) {
		log.info("AccountServiceImpl search method start");
		List<AccountDTO> list=dao.search(dto, pageNo, pageSize);
		log.info("AccountServiceImpl search method end");
		return list;
	}

	

	

	
}
