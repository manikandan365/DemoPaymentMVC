package in.co.my.bank.ctl;

import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import in.co.my.bank.dto.AccountDTO;
import in.co.my.bank.dto.TransactionDTO;
import in.co.my.bank.form.TransactionForm;
import in.co.my.bank.service.AccountServiceInt;
import in.co.my.bank.service.TransactionServiceInt;
import in.co.my.bank.util.DataUtility;
import in.co.my.bank.util.EmailBuilder;

@Controller
public class TransactionCtl extends BaseCtl {

	private Logger log = Logger.getLogger(TransactionCtl.class.getName());

	@Autowired
	private TransactionServiceInt service;

	@Autowired
	private AccountServiceInt accountService;
	
	@Autowired
	private JavaMailSenderImpl mailSender;

	@ModelAttribute
	public void preload(Model model) {
		model.addAttribute("accountList", accountService.search(null));
	}

	@GetMapping("/ctl/transaction")
	public String display(@ModelAttribute("form") TransactionForm form, Model model) {
		log.info("TransactionCtl Transaction display method start");
		if (form.getId() > 0) {
			form.populate(service.findBypk(form.getId()));
		}
		log.info("TransactionCtl Transaction display method end");
		return "transaction";
	}

	@PostMapping("/ctl/transaction")
	public String submit(@RequestParam String operation, @Valid @ModelAttribute("form") TransactionForm form,
			BindingResult bindingResult, Model model) {

		log.info("TransactionCtl Transaction submit method start");

		if (OP_RESET.equalsIgnoreCase(form.getOperation())) {
			return "redirect:/ctl/transaction";
		}

		if (bindingResult.hasErrors()) {
			System.out.println(bindingResult);
			return "transaction";
		}

		if (OP_PAY.equalsIgnoreCase(form.getOperation())) {
			TransactionDTO dto = (TransactionDTO) form.getDTO();
			AccountDTO toAccount=accountService.findByAccountNo(dto.getToAccount());
			AccountDTO fromAccount=accountService.findByAccountNo(dto.getFromAccount());
			if (toAccount.getBalance() > dto.getAmount()) {
				if (toAccount.getBalance() - dto.getAmount() > 200.0) {
					toAccount.setBalance(toAccount.getBalance()-dto.getAmount());
					fromAccount.setBalance(fromAccount.getBalance()+dto.getAmount());
					accountService.update(toAccount);
					accountService.update(fromAccount);
					dto.setTransactionId(DataUtility.getTransactionId());
					dto.setDate(new java.util.Date());
					service.add(dto);
					
					sendMailToAccount(toAccount,dto.getAmount(),dto.getFromAccount());
					sendMailFromAccount(fromAccount,dto.getAmount(),dto.getToAccount());
					
					model.addAttribute("success", "Payment Transfer Successfully!!!!");
					return "transaction";
				} else {
					model.addAttribute("error", "Insufficient Balance");
					return "transaction";
				}
			} else {
				model.addAttribute("error", "Insufficient Balance");
				return "transaction";
			}
		}

		log.info("TransactionCtl Transaction submit method end");
		return "transaction";
	}

	private void sendMailFromAccount(AccountDTO fromAccount, double amount, long toAccount) {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("name", fromAccount.getName());
		map.put("amount",String.valueOf(amount));
		map.put("account", String.valueOf(toAccount));

		String message = EmailBuilder.getTransactionMessage(map);

		MimeMessage msg = mailSender.createMimeMessage();

		try {
			MimeMessageHelper helper = new MimeMessageHelper(msg);
			helper.setTo(fromAccount.getEmail());
			helper.setSubject("My Bank Transaction");
			helper.setText(message, true);
			mailSender.send(msg);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		
	}

	private void sendMailToAccount(AccountDTO toAccount, double amount, long fromAccount) {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("name", toAccount.getName());
		map.put("amount",String.valueOf(amount));
		map.put("account", String.valueOf(fromAccount));

		String message = EmailBuilder.getTransactionMessage(map);

		MimeMessage msg = mailSender.createMimeMessage();

		try {
			MimeMessageHelper helper = new MimeMessageHelper(msg);
			helper.setTo(toAccount.getEmail());
			helper.setSubject("My Bank Transaction");
			helper.setText(message, true);
			mailSender.send(msg);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		
	}

	@RequestMapping(value = "/ctl/transaction/search", method = { RequestMethod.GET, RequestMethod.POST })
	public String searchList(HttpSession session, @ModelAttribute("form") TransactionForm form,
			@RequestParam(required = false) String operation,Long acNo, Model model) {

		if (OP_RESET.equalsIgnoreCase(operation)) {
			return "redirect:/ctl/transaction/search";
		}

		
		int pageNo = form.getPageNo();
		int pageSize = form.getPageSize();

		if (OP_NEXT.equalsIgnoreCase(operation)) {
			pageNo++;
		} else if (OP_PREVIOUS.equalsIgnoreCase(operation)) {
			pageNo--;
		}

		pageNo = (pageNo < 1) ? 1 : pageNo;
		pageSize = (pageSize < 1) ? 10 : pageSize;

		TransactionDTO dto = (TransactionDTO) form.getDTO();
		if(DataUtility.getLong(String.valueOf(acNo))>0) {
			dto.setToAccount(DataUtility.getLong(String.valueOf(acNo)));
		}
		List<TransactionDTO> list = service.search(dto, pageNo, pageSize);

		List<TransactionDTO> totallist = service.search(dto);

		model.addAttribute("list", list);

		if (list.size() == 0) {
			model.addAttribute("error", "Record Not found");
		}
		int listsize = list.size();
		int total = totallist.size();
		int pageNoPageSize = pageNo * pageSize;

		form.setPageNo(pageNo);
		form.setPageSize(pageSize);

		model.addAttribute("total", total);
		model.addAttribute("pageNo", pageNo);
		model.addAttribute("pageSize", pageSize);
		model.addAttribute("listsize", listsize);
		model.addAttribute("pagenosize", pageNoPageSize);
		return "transactionList";
	}
}
