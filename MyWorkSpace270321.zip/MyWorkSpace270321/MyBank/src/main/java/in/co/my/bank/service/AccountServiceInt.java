package in.co.my.bank.service;

import java.util.List;

import in.co.my.bank.dto.AccountDTO;

public interface AccountServiceInt {


	public void delete(AccountDTO dto);

	public AccountDTO findBypk(long pk);

	public AccountDTO findByLogin(String login);

	public void update(AccountDTO dto) ;

	public List<AccountDTO> search(AccountDTO dto);
	
	public AccountDTO findByAccountNo(long accountNo);

	public List<AccountDTO> search(AccountDTO dto, int pageNo, int pageSize);

	
	  

}
