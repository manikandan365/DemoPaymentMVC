package in.co.my.bank.dto;

import java.math.BigDecimal;
import java.text.DecimalFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="ACCOUNT")
public class AccountDTO extends BaseDTO {

	@Column(name="NAME" ,length = 225)
	private String name;
	@Column(name="EMAIL" ,length = 225)
	private String email;
	@Column(name="ACCOUNT_NO")
	private long accountNo;
	@Column(name="BALANCE")
	private double balance;
	
	
	@Override
	public String getKey() {
		return String.valueOf(id);
	}
	@Override
	public String getValue() {
		return String.valueOf(accountNo);
	}
	
	
}
