package in.co.my.bank.dao;

import java.util.List;

import in.co.my.bank.dto.AccountDTO;


public interface AccountDAOInt {

	
	public void delete(AccountDTO dto);
	
	public AccountDTO findBypk(long pk);
	
	public AccountDTO findByLogin(String login);
	
	public AccountDTO findByAccountNo(long accountNo);
	
	public void update(AccountDTO dto);
	
	public List<AccountDTO> search(AccountDTO dto);
	
	public List<AccountDTO> search(AccountDTO dto,int pageNo,int pageSize);
	
}
